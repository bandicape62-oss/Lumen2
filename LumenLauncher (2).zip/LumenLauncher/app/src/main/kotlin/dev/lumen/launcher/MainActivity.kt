package dev.lumen.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import dev.lumen.launcher.bedrock.BedrockPatcher
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { Home() } } }
    }

    @Composable
    private fun Home() {
        val shadersRoot = remember { File(getExternalFilesDir(null), "shaders").apply { mkdirs() } }
        var shaders by remember { mutableStateOf(shadersRoot.listFiles { f -> f.isDirectory }?.toList().orEmpty()) }
        var selected by remember { mutableStateOf<File?>(null) }
        var status by remember { mutableStateOf("") }
        val mc = remember { BedrockPatcher.detect(this) }

        Column(Modifier.padding(20.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Lumen", style = MaterialTheme.typography.headlineMedium)
            Text(if (mc == null) "Minecraft Bedrock no está instalado" else "Minecraft ${mc.versionName}")
            Text("Pon cada shader en una carpeta con sus .material.bin dentro de:\n${shadersRoot.absolutePath}",
                style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = {
                shaders = shadersRoot.listFiles { f -> f.isDirectory }?.toList().orEmpty()
            }) { Text("Actualizar lista") }

            LazyColumn(Modifier.weight(1f)) {
                items(shaders) { dir ->
                    ListItem(
                        headlineContent = { Text(dir.name) },
                        trailingContent = { RadioButton(selected == dir, onClick = { selected = dir }) },
                        modifier = Modifier.clickable { selected = dir }
                    )
                }
            }
            if (status.isNotEmpty()) Text(status)
            Button(
                enabled = mc != null && selected != null,
                onClick = {
                    status = try {
                        val r = BedrockPatcher.build(this@MainActivity, mc!!, selected!!)
                        val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", r.apk)
                        startActivity(Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "application/vnd.android.package-archive")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                        "Reemplazados ${r.replaced} de ${r.total} materiales"
                    } catch (e: Exception) { "Error: ${e.message}" }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Parchear e instalar") }
        }
    }
}
