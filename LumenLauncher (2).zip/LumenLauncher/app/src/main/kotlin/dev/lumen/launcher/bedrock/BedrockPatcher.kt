package dev.lumen.launcher.bedrock

import android.content.Context
import android.content.pm.PackageManager
import com.android.apksig.ApkSigner
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object BedrockPatcher {
    const val MC_PACKAGE = "com.mojang.minecraftpe"
    private const val MATERIALS_DIR = "assets/renderer/materials/"

    data class McInfo(val versionName: String, val versionCode: Long, val apks: List<File>)
    data class Result(val apk: File, val replaced: Int, val total: Int)

    fun detect(ctx: Context): McInfo? = try {
        val pi = ctx.packageManager.getPackageInfo(MC_PACKAGE, 0)
        val ai = pi.applicationInfo ?: return null
        val apks = buildList { add(File(ai.sourceDir)); ai.splitSourceDirs?.forEach { add(File(it)) } }
        McInfo(pi.versionName ?: "?", pi.longVersionCode, apks)
    } catch (e: PackageManager.NameNotFoundException) { null }

    /** Reemplaza .material.bin del APK por los de shaderDir, firma y devuelve el resultado. */
    fun build(ctx: Context, info: McInfo, shaderDir: File): Result {
        val outDir = File(ctx.getExternalFilesDir(null), "out").apply { mkdirs() }
        val unsigned = File(outDir, "unsigned.apk")
        val signed = File(outDir, "minecraft-patched.apk")

        val repl = shaderDir.walkTopDown()
            .filter { it.isFile && it.name.endsWith(".material.bin") }
            .associateBy { it.name }
        require(repl.isNotEmpty()) { "El shader no tiene archivos .material.bin" }

        val source = info.apks.firstOrNull { apk ->
            ZipFile(apk).use { z -> z.entries().asSequence().any { it.name.startsWith(MATERIALS_DIR) } }
        } ?: error("No se encontraron materiales en el APK de Minecraft")

        var replaced = 0; var total = 0
        ZipFile(source).use { zin ->
            ZipOutputStream(FileOutputStream(unsigned)).use { zout ->
                for (e in zin.entries()) {
                    if (e.name.startsWith("META-INF/")) continue
                    val isMat = e.name.startsWith(MATERIALS_DIR) && e.name.endsWith(".material.bin")
                    if (isMat) total++
                    val r = if (isMat) repl[e.name.substringAfterLast('/')] else null
                    zout.putNextEntry(ZipEntry(e.name).apply { time = e.time })
                    if (r != null) { r.inputStream().use { it.copyTo(zout) }; replaced++ }
                    else zin.getInputStream(e).use { it.copyTo(zout) }
                    zout.closeEntry()
                }
            }
        }
        sign(ctx, unsigned, signed)
        unsigned.delete()
        return Result(signed, replaced, total)
    }

    /** Firma con assets/lumen.p12 (clave "lumen", contraseña "lumen123"). Ver README. */
    private fun sign(ctx: Context, input: File, output: File) {
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("lumen.p12").use { ks.load(it, "lumen123".toCharArray()) }
        val key = ks.getKey("lumen", "lumen123".toCharArray()) as PrivateKey
        val cert = ks.getCertificate("lumen") as X509Certificate
        val cfg = ApkSigner.SignerConfig.Builder("lumen", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input).setOutputApk(output)
            .setMinSdkVersion(26)
            .setV1SigningEnabled(false).setV2SigningEnabled(true).setV3SigningEnabled(true)
            .build().sign()
    }
}
