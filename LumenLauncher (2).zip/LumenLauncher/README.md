# Lumen Launcher (proyecto propio)

## Compilar
1. Abre la carpeta en Android Studio (Ladybug o más nuevo) y deja que sincronice.
2. Crea el keystore de firma y ponlo en `app/src/main/assets/`:
   keytool -genkeypair -keystore app/src/main/assets/lumen.p12 -storetype PKCS12 \
     -alias lumen -keyalg RSA -keysize 2048 -validity 9999 \
     -storepass lumen123 -keypass lumen123 -dname "CN=Lumen"
3. Build > Build APK(s).

## Usar
Copia carpetas de shaders (con `.material.bin` de TU versión de Minecraft) a
`Android/data/dev.lumen.launcher/files/shaders/<nombre>/`, abre la app, elige y pulsa "Parchear e instalar".

## Límites conocidos
- El APK parcheado lleva otra firma: Android no lo instala encima del Minecraft original
  (hay que desinstalar el original o cambiar el nombre de paquete del clon, pendiente).
- Si Minecraft viene en splits, instalar solo el base puede fallar.
- Los .material.bin deben coincidir con la versión del juego.
